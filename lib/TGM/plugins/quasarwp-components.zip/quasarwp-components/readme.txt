=== QuasarWP Components Plugin ===
Contributors: amimaro
Requires at least: 1.0.0
Tested up to: 1.0.0
Stable tag: 1.0.0
License: GPLv3

== Description ==

Components for QuasarWP parent theme.


== Changelog ==

= 1.0.1 =
* Minor tidying up.

= 1.0 =
* Initial release.


== Installation ==

1. Extract the .zip file for this plugin and upload its contents to the `/wp-content/plugins/` directory.
1. Activate the plugin through the "Plugins" menu in WordPress.

